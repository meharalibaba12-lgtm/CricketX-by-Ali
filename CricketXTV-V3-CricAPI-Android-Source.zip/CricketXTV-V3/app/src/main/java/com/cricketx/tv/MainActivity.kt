package com.cricketx.tv

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF090E18)
private val Panel = Color(0xFF151E2D)
private val Accent = Color(0xFFE53945)
private val Muted = Color(0xFF9AA8BA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CricketXApp() }
    }
}

@Composable
fun CricketXApp() {
    val context = LocalContext.current
    val favoritesStore = remember { FavoritesStore(context) }
    var favorites by remember { mutableStateOf(favoritesStore.getAll()) }
    var tab by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf<Channel?>(null) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column {
                Row(
                    Modifier.fillMaxWidth().padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("CRICKETX", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text(" TV", color = Accent, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.weight(1f))
                    Text("SPORTS HUB", color = Muted, fontSize = 10.sp)
                }

                if (selected != null) {
                    PlayerScreen(channel = selected!!, onBack = { selected = null })
                } else {
                    when (tab) {
                        "Home" -> HomeScreen(
                            onLive = { tab = "Live TV" },
                            onScores = { tab = "Scores" }
                        )
                        "Scores" -> ScoresScreen()
                        "Live TV" -> ChannelScreen(
                            channels = channelCatalog,
                            favorites = favorites,
                            onFavorite = { favorites = favoritesStore.toggle(it.id) },
                            onSelect = { selected = it }
                        )
                        "Saved" -> ChannelScreen(
                            channels = channelCatalog.filter { favorites.contains(it.id) },
                            favorites = favorites,
                            onFavorite = { favorites = favoritesStore.toggle(it.id) },
                            onSelect = { selected = it }
                        )
                        else -> SettingsScreen()
                    }
                }

                Spacer(Modifier.weight(1f, fill = false))
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(tab == "Home", { tab = "Home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(tab == "Scores", { tab = "Scores" }, icon = { Icon(Icons.Default.SportsCricket, null) }, label = { Text("Scores") })
                    NavigationBarItem(tab == "Live TV", { tab = "Live TV" }, icon = { Icon(Icons.Default.LiveTv, null) }, label = { Text("Live TV") })
                    NavigationBarItem(tab == "Saved", { tab = "Saved" }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("Saved") })
                    NavigationBarItem(tab == "Settings", { tab = "Settings" }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                }
            }
        }
    }
}

@Composable
fun ColumnScope.HomeScreen(onLive: () -> Unit, onScores: () -> Unit) {
    LazyColumn(
        modifier = Modifier.weight(1f),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(
                Modifier.fillMaxWidth().background(
                    androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF8C1828), Color(0xFF25213B))),
                    RoundedCornerShape(20.dp)
                ).padding(20.dp)
            ) {
                Text("YOUR SPORTS HUB", color = Color.White.copy(alpha = .75f), fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Text("Every Match.\nOne Place.", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onLive, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                        Text("Live TV")
                    }
                    OutlinedButton(onClick = onScores) { Text("Cricket Scores") }
                }
            }
        }
        item { SectionTitle("Getting started") }
        item {
            InfoCard("Live channels", "Add streams you own or are licensed to distribute in Models.kt.")
        }
        item {
            InfoCard("Live scores", "Connect a cricket data provider in ScoreApi.kt. Until then, the Scores tab clearly shows demo fixtures.")
        }
        item {
            InfoCard("Official broadcasters", "Add verified broadcaster website URLs to a channel's officialUrl field. The app opens these in your browser.")
        }
    }
}


@Composable
fun ColumnScope.ScoresScreen() {
    val scope = rememberCoroutineScope()
    var matches by remember { mutableStateOf(emptyList<CricketMatch>()) }
    var apiKey by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var message by remember {
        mutableStateOf("Enter a free CricAPI key to load current international, domestic and league matches. No demo scores are shown as live.")
    }

    Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionTitle("Live Cricket Scores")
            Spacer(Modifier.weight(1f))
            if (loading) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = apiKey,
            onValueChange = { apiKey = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("CricAPI key") },
            placeholder = { Text("Paste your API key") },
            singleLine = true
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                scope.launch {
                    loading = true
                    message = "Fetching current matches…"
                    try {
                        matches = withContext(Dispatchers.IO) {
                            ScoreApi.fetchCurrentMatches(apiKey)
                        }
                        message = "Provider: CricAPI • ${matches.size} current matches returned. Refresh manually to conserve your free quota."
                    } catch (e: Exception) {
                        message = e.message ?: "Could not load scores."
                    } finally {
                        loading = false
                    }
                }
            },
            enabled = !loading && apiKey.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = Accent)
        ) {
            Text("Fetch current matches")
        }
        Spacer(Modifier.height(8.dp))
        Text(message, color = Muted, fontSize = 12.sp)
        Text("CricAPI free tier is advertised at 100 requests/day. Check your account quota and usage terms.", color = Muted, fontSize = 11.sp)
        LazyColumn(
            contentPadding = PaddingValues(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(matches) { MatchCard(it) }
        }
    }
}

@Composable
fun MatchCard(match: CricketMatch) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(15.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(match.title, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(match.source, color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Text(match.status, color = Muted, fontSize = 12.sp)
        Text(match.score, color = Color.White, fontSize = 16.sp)
    }
}

@Composable
fun ColumnScope.ChannelScreen(
    channels: List<Channel>,
    favorites: Set<String>,
    onFavorite: (Channel) -> Unit,
    onSelect: (Channel) -> Unit
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search channels") },
            singleLine = true
        )
        LazyColumn(
            contentPadding = PaddingValues(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(channels.filter { it.name.contains(query, true) || it.category.contains(query, true) }) { channel ->
                ChannelCard(
                    channel = channel,
                    isFavorite = favorites.contains(channel.id),
                    onFavorite = { onFavorite(channel) },
                    onSelect = { onSelect(channel) },
                    onOfficial = {
                        if (channel.officialUrl.startsWith("https://")) {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(channel.officialUrl)))
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun ChannelCard(
    channel: Channel,
    isFavorite: Boolean,
    onFavorite: () -> Unit,
    onSelect: () -> Unit,
    onOfficial: () -> Unit
) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.LiveTv, null, tint = Accent, modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).clickable { onSelect() }) {
                Text(channel.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(channel.category, color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onFavorite) {
                Icon(Icons.Default.Favorite, null, tint = if (isFavorite) Accent else Muted)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = onSelect) { Text("Open player") }
            TextButton(
                onClick = onOfficial,
                enabled = channel.officialUrl.startsWith("https://")
            ) { Text("Official website") }
        }
    }
}

@Composable
fun ColumnScope.PlayerScreen(channel: Channel, onBack: () -> Unit) {
    val context = LocalContext.current
    val player = remember(channel.streamUrl) {
        ExoPlayer.Builder(context).build().apply {
            if (channel.streamUrl.startsWith("https://")) {
                setMediaItem(MediaItem.fromUri(channel.streamUrl))
                prepare()
                playWhenReady = true
            }
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    Column(Modifier.weight(1f).padding(16.dp)) {
        Text("‹ Back", color = Accent, modifier = Modifier.clickable { onBack() }.padding(vertical = 10.dp))
        Text(channel.name, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (channel.streamUrl.startsWith("https://")) {
            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
            )
        } else {
            Box(
                Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                    .background(Color.Black, RoundedCornerShape(12.dp)).padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("PLAYER READY\n\nNo authorized stream URL configured.", color = Color.White)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Only use streams you own or are licensed to distribute.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun ColumnScope.SettingsScreen() {
    Column(Modifier.weight(1f).padding(20.dp)) {
        SectionTitle("Settings")
        Spacer(Modifier.height(12.dp))
        Text("CricketX TV • Version 2.0", color = Color.White)
        Text("Dark theme enabled", color = Muted)
        Text("Favorites are stored on this device.", color = Muted)
        Text("Score provider: CricAPI current matches", color = Muted)
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(15.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(body, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
}
