package com.cricketx.tv

import android.content.Context

class FavoritesStore(context: Context) {
    private val prefs = context.getSharedPreferences("cricketx_favorites", Context.MODE_PRIVATE)

    fun getAll(): Set<String> = prefs.getStringSet("channels", emptySet())?.toSet() ?: emptySet()

    fun toggle(channelId: String): Set<String> {
        val updated = getAll().toMutableSet()
        if (!updated.add(channelId)) updated.remove(channelId)
        prefs.edit().putStringSet("channels", updated).apply()
        return updated
    }
}
