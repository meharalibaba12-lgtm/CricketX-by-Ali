package com.cricketx.tv

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/*
 * CricAPI / CricketData.org free Current Matches endpoint.
 * Endpoint: https://api.cricapi.com/v1/currentMatches?apikey=KEY&offset=0
 *
 * Public provider information currently advertises 100 free hits/day for
 * basic current-match data. Verify terms, quotas and competition coverage
 * in your own account before distributing an app.
 *
 * Prototype note: passing a key from the Android client exposes it to a
 * determined APK/network inspector. For public production, move this request
 * behind your own HTTPS backend and keep the key server-side.
 */
object ScoreApi {
    fun fetchCurrentMatches(apiKey: String): List<CricketMatch> {
        require(apiKey.isNotBlank()) { "Enter your CricAPI key first." }
        val encodedKey = URLEncoder.encode(apiKey.trim(), "UTF-8")
        val endpoint = "https://api.cricapi.com/v1/currentMatches?apikey=$encodedKey&offset=0"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("Accept", "application/json")
        }

        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) error("CricAPI HTTP $code: $body")

            val root = JSONObject(body)
            val status = root.optString("status")
            if (status.equals("failure", true)) {
                val reason = root.optString("reason", "Provider rejected the request.")
                error(reason)
            }

            val data = root.optJSONArray("data") ?: error(
                root.optString("reason", "No match data returned by provider.")
            )

            return (0 until data.length()).mapNotNull { index ->
                val item = data.optJSONObject(index) ?: return@mapNotNull null
                val teams = item.optJSONArray("teams")
                val title = item.optString("name").ifBlank {
                    if (teams != null && teams.length() >= 2) {
                        "${teams.optString(0)} vs ${teams.optString(1)}"
                    } else "Cricket match"
                }

                val scoreArray = item.optJSONArray("score")
                val scoreText = if (scoreArray != null && scoreArray.length() > 0) {
                    (0 until scoreArray.length()).mapNotNull { scoreIndex ->
                        val score = scoreArray.optJSONObject(scoreIndex) ?: return@mapNotNull null
                        val inning = score.optString("inning")
                        val runs = score.optString("r", "?")
                        val wickets = score.optString("w", "?")
                        val overs = score.optString("o", "?")
                        "$inning: $runs/$wickets ($overs ov)"
                    }.joinToString("\n").ifBlank { "Score not available" }
                } else {
                    "Score not available"
                }

                CricketMatch(
                    id = item.optString("id", "cricapi-$index"),
                    title = title,
                    status = item.optString("status", "Status unavailable"),
                    score = scoreText,
                    source = "CricAPI"
                )
            }
        } finally {
            connection.disconnect()
        }
    }
}
