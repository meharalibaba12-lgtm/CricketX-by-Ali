package com.cricketx.tv

data class Channel(
    val id: String,
    val name: String,
    val category: String,
    val streamUrl: String = "",
    val officialUrl: String = ""
)

data class CricketMatch(
    val id: String,
    val title: String,
    val status: String,
    val score: String,
    val source: String = "DEMO"
)

/*
 * Add your licensed channels here.
 * Leave streamUrl/officialUrl blank until you have verified authorized URLs.
 */
val channelCatalog = listOf(
    Channel("c1", "Cricket Channel 1", "Cricket"),
    Channel("c2", "Cricket Channel 2", "Cricket"),
    Channel("s1", "Sports Channel", "Sports"),
    Channel("f1", "Football Channel", "Football")
)

/*
 * Demo data only. These are not real-time scores.
 * Replace with your contracted cricket data provider.
 */
val demoMatches = listOf(
    CricketMatch("m1", "Pakistan vs India", "Demo fixture • Not live", "Score unavailable"),
    CricketMatch("m2", "Australia vs England", "Demo fixture • Not live", "Score unavailable"),
    CricketMatch("m3", "New Zealand vs South Africa", "Demo fixture • Not live", "Score unavailable")
)
