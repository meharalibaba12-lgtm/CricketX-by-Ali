# CricketX TV Version 3.0 — CricAPI integration

## نیا کیا ہے؟
- CricAPI / CricketData.org کے Current Matches endpoint سے current match list
- International، domestic اور league matches جو provider اس endpoint میں واپس کرے
- API key app کے Scores tab میں paste کریں؛ repository میں key شامل نہیں
- Manual refresh تاکہ free quota ضائع نہ ہو
- Live match scores اور status کو provider کے مطابق render کرنا
- Favorites، channel directory، HLS player اور official website fields برقرار

## Free API
Provider کا صفحہ basic Current Matches API کے لیے lifetime free access اور 100 hits/day بتاتا ہے:
https://cricketdata.org/cricket-live-score-api/

Free key حاصل کرنے کے لیے:
https://cricketdata.org/
یا API account/member area استعمال کریں۔

Endpoint:
https://api.cricapi.com/v1/currentMatches?apikey=YOUR_KEY&offset=0

اہم: provider کہتا ہے کہ current matches میں تمام موجودہ میچز آتے ہیں اور score fields میں runs, wickets, overs شامل ہوتے ہیں۔ Coverage، update speed، استعمال کے حقوق، quotas اور terms اپنے account میں verify کریں۔ ان کی معلومات کے مطابق score data دستی طور پر update ہو سکتا ہے اور event کے تقریباً ایک منٹ کے اندر دستیاب ہو سکتا ہے؛ اسے ball-by-ball guaranteed feed نہ سمجھیں۔

## موبائل سے APK build
1. GitHub پر repository بنائیں۔
2. اس ZIP کی تمام files اور folders repository میں upload کریں۔
3. Actions tab میں `Build CricketX TV APK` workflow چلائیں۔
4. Build مکمل ہونے پر Artifacts سے `CricketXTV-v3-debug-apk` artifact ڈاؤن لوڈ کریں۔
5. ZIP extract کرکے `app-debug.apk` install کریں۔

اگر پہلے سے V2 repo ہے تو V3 کے تمام files اسی structure میں overwrite کریں، خاص طور پر MainActivity.kt، ScoreApi.kt اور app/build.gradle.kts۔

## API key safety
یہ prototype key کو صرف input کے ذریعے runtime میں لیتا ہے اور GitHub source میں commit نہیں کرتا۔ تاہم APK میں client-side API key مکمل محفوظ نہیں رہ سکتی؛ public app کے لیے backend proxy بنائیں، key server-side رکھیں، per-user rate limits لگائیں اور API provider کی redistribution/commercial-use terms پڑھیں۔

## Stream rights
یہ app خود TV broadcast rights نہیں دیتی۔ صرف اپنے یا تحریری اجازت/لائسنس والے HLS streams استعمال کریں۔ Official broadcaster links صرف verified official websites کے ہوں۔

## Build configuration
- minSdk 23
- targetSdk 35
- Kotlin + Jetpack Compose
- AndroidX Media3 ExoPlayer
- Gradle 8.9 / JDK 17
